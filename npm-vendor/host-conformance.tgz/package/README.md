# @panphora/host-conformance

The Malleable Document host conformance suite: the HTTP checks any host in any
language can run against itself, the browser page that checks a host in a real
browser, and the shared test vectors both share.

This package currently carries the HTTP engine. The checks talk nothing but
HTTP: point them at a running development host and they report whether it is a
conformant host or merely a server that happens to write files.

```js
import { runConformance } from '@panphora/host-conformance';

const { checks } = await runConformance({ base: 'http://localhost:4321' });
```

Each check is `{ id, title, engine, status, detail, blocking }`, where `id` is
`http.h1` through `http.h12` and `status` is `pass`, `fail` or `skip`.

## What it checks

| | |
|---|---|
| H1 | the bytes a save sends are the bytes a read returns, across every canonical fixture |
| H2 | serving never mutates the stored document (200 reads, digest unchanged) |
| H3 | an injected `savetoken` round-trips and never reaches the stored document |
| H4 | `documentid` round-trips, and a copy gets a fresh one |
| H5 | `/_/meta` answers a capability document or a clean 404, never anything else |
| H6 | `/_/meta` cannot be used to probe for documents a caller cannot see |
| H7 | a stale `If-Match` refuses with 412 and writes nothing |
| H8 | cross-origin saves are refused, and `Origin: null` without a token is refused |
| H9 | path traversal is refused in every spelling |
| H10 | a non-HTML body is 422 and a JSON envelope is 415 |
| H11 | an over-limit body is 413 with no partial write |
| H12 | a kill mid-write leaves the previous document intact |

It writes to a probe document, so point it at a development host, never at
anything you care about.

## License

See [LICENSE](LICENSE).
