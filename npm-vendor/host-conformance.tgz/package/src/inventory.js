import { readFile } from 'node:fs/promises';

// checks.json is the published list of check ids. A run is only an answer if
// every id on that list reported: a check that silently vanished (a page that
// stopped emitting a row, an engine that skipped one) must not read as a pass,
// and a row nobody has ever heard of must not slip into the report unremarked.

const shortId = (id) => id.toLowerCase().replace(/^(http|page)\./, '');

export async function loadInventory(file) {
  const parsed = JSON.parse(await readFile(file, 'utf8'));
  if (!Array.isArray(parsed.checks)) throw new Error(`${file} has no checks array`);
  return parsed.checks;
}

export function expectedIds(inventory, { engine = 'all', only = [], extra = [], profile = null } = {}) {
  const engines = engine === 'all' ? 'all' : [engine].flat();
  const wanted = new Set(only.map(shortId));
  const ids = inventory
    .filter((check) => engines === 'all' || engines.includes(check.engine))
    .filter((check) => !check.profile || check.profile === profile)
    .map((check) => check.id)
    .filter((id) => wanted.size === 0 || wanted.has(shortId(id)));
  return [...ids, ...extra];
}

export function reconcileInventory(checks, { expected, inventory }) {
  const known = new Set(inventory.map((check) => check.id));
  const reconciled = checks.map((check) => {
    if (known.has(check.id) || expected.includes(check.id)) return check;
    return {
      ...check,
      status: 'na',
      blocking: true,
      detail: `this is not a check id in checks.json: ${check.id}`,
    };
  });

  const reported = new Set(reconciled.map((check) => check.id));
  for (const id of expected) {
    if (reported.has(id)) continue;
    const listed = inventory.find((check) => check.id === id);
    reconciled.push({
      id,
      title: null,
      engine: listed?.engine ?? null,
      status: 'na',
      blocking: true,
      detail: 'this check did not report',
    });
  }
  return reconciled;
}
