import { req } from './http.js';

// Most rows are conditional on a capability the host announces in `/_/meta`, so
// a host could pass by quietly dropping one: delete `rooms` from the list and
// the rooms rows turn into skips. A host that is meant to stay a full host
// passes those names in as `--require-extensions`, and each one becomes a check
// of its own that a waiver can name like any other.
//
// Read once, before the engines run, so every capability row sees the same
// answer.

export async function readAnnounced({ url, headers = {}, cookies = [] }) {
  const response = await req(url, '/_/meta', {
    headers: { ...headers, ...(cookies.length ? { cookie: cookies.join('; ') } : {}) },
  });
  if (response.status === 404) return { state: 'none', names: [] };
  if (response.status !== 200 || response.json === null || typeof response.json !== 'object') {
    return { state: 'unreadable', names: [], detail: `/_/meta answered ${response.status} with no JSON object` };
  }
  const listed = response.json.extensions;
  if (listed === undefined) return { state: 'ok', names: [] };
  if (!Array.isArray(listed)) return { state: 'malformed', names: [], detail: '`extensions` is not an array' };
  return { state: 'ok', names: listed };
}

export function capabilityChecks(announced, required) {
  const listed = new Set(announced);
  return required.map((name) => ({
    id: `capability.${name}`,
    title: `this host announces \`${name}\``,
    engine: 'http',
    status: listed.has(name) ? 'pass' : 'fail',
    detail: `this host must announce ${name}`,
    blocking: false,
  }));
}

export function registeredCheck(read, registry) {
  const base = {
    id: 'capability.registered',
    title: 'every extension this host announces is in the registry',
    engine: 'http',
    blocking: false,
  };
  if (read.state === 'unreadable') return { ...base, status: 'na', blocking: true, detail: read.detail };
  if (read.state === 'malformed') return { ...base, status: 'fail', detail: read.detail };
  const seen = new Set();
  const bad = [];
  for (const name of read.names) {
    if (typeof name !== 'string') bad.push(`not a string: ${JSON.stringify(name)}`);
    else if (seen.has(name)) bad.push(`announced twice: ${name}`);
    else if (!registry.has(name)) bad.push(`not registered: ${name}`);
    if (typeof name === 'string') seen.add(name);
  }
  if (bad.length) return { ...base, status: 'fail', detail: bad.join('; ') };
  return { ...base, status: 'pass', detail: `${read.names.length} announced, all registered` };
}
