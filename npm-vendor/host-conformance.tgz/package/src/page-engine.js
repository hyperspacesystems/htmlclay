// The page engine. Drives host-test.html against a live host in a real browser and
// returns the rows it produces as checks, so one runner can report it beside the HTTP
// engine.
//
// The page has to run IN A BROWSER and FROM THE HOST'S OWN ORIGIN: the spec requires
// exact origin validation on every save, so a save can only be proven from the origin
// that will be allowed to make it, and the cross-origin check needs a real sandboxed
// iframe with a real opaque origin. Neither survives being reimplemented in node.
//
// So this does three things and nothing else: copy the page into the host's document
// root, open it there, and read back the rows the page produces. Everything specific
// to a host -- how it boots, where its document root is, whether it mints a token --
// belongs to that host's own CI step, which passes the answers in as arguments.
//
//   runPageEngine({ url: 'http://127.0.0.1:4321', root: '/tmp/served-folder' })
//   runPageEngine({ url: 'http://127.0.0.1:7311', page: 'doc.htmlclay', tokenFromPage: true })
//   runPageEngine({ url: 'https://site.localhost', page: 'doc.html', cookies: ['auth_token=...'], insecure: true })
//
// `root` copies the page in; omit it when the host has to prepare the page itself.
// A token host mints the token at serve time and binds it to ONE file, so the page
// has to be registered with the host before it is served, which only the host can do.
// There the host puts the page in place, `page` names where it landed, and
// `tokenFromPage` takes the token the host injected rather than inventing one.
//
// `cookies` is for a cookie host, where logging in is the host's own flow and a
// conformance runner has no business knowing anybody's credentials. `insecure` is for
// a dev host whose certificate no store trusts; it is never on by default.
//
// A `skip` is not a failure. A host that never announces `upload` is conforming, and
// treating its skips as red would make the gate unusable on exactly the hosts it is
// meant to protect. Only `fail` fails.
//
// The exception is a row marked `blocking`, which is a check the spec requires of
// every host. Those cannot be skipped, only run: a blocking row that ends `na` means
// the harness could not answer, and `unanswered` carries it so the caller can stop
// rather than read "could not check" as "conforms".

import { readFile, writeFile, rm, lstat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import path from 'node:path';

const HERE = path.dirname(fileURLToPath(import.meta.url));

// Two layouts, because the page is copied into this package at prepack time. Inside
// the package it sits under page/; in the source tree that copy may not have been made
// yet, and the one canonical page is three levels up at the repo root. The packaged
// copy is checked FIRST, so a host that installed this package reads the page that
// shipped with it.
const PAGE = [
  path.join(HERE, '..', 'page', 'host-test.html'),
  path.join(HERE, '..', '..', '..', 'host-test.html'),
].find((p) => existsSync(p)) || path.join(HERE, '..', '..', '..', 'host-test.html');

// The name is deliberately ugly and prefixed: it lands in someone's document folder,
// and on a token host the page overwrites ITSELF as the test target, so it must never
// collide with a document a person cares about.
export const SERVED_NAME = '_mhf-host-test.html';
const SCRATCH_NAME = '_mhf-host-test-scratch.html';

export function parseArgs(argv) {
  const out = { token: '', target: '', page: '', root: '', cookies: [], tokenFromPage: false, keep: false, insecure: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--url') out.url = argv[++i];
    else if (a === '--root') out.root = argv[++i];
    else if (a === '--page') out.page = argv[++i];
    else if (a === '--token') out.token = argv[++i];
    else if (a === '--target') out.target = argv[++i];
    else if (a === '--cookie') out.cookies.push(argv[++i]);
    else if (a === '--token-from-page') out.tokenFromPage = true;
    else if (a === '--keep') out.keep = true;
    else if (a === '--insecure') out.insecure = true;
    else throw new Error(`unknown flag ${a}`);
  }
  if (!out.url) throw new Error('--url is required (the host\'s origin, e.g. http://127.0.0.1:4321)');
  if (!out.root && !out.page) throw new Error('one of --root (copy the page in) or --page (the host already serves it) is required');
  if (!out.page) out.page = SERVED_NAME;
  return out;
}

// Resolved from the CALLER'S directory, not this script's. The runner lives in the
// spec repo but is meant to be invoked from whichever host repo is being gated, and
// that repo is where playwright is installed. A bare `import('playwright')` resolves
// against this file and would only ever find a copy this package does not have.
// CONFORMANCE_PLAYWRIGHT_ROOT names another root explicitly, for a caller whose
// working directory is not the repo playwright lives in.
function playwrightRoots() {
  const roots = [process.cwd()];
  if (process.env.CONFORMANCE_PLAYWRIGHT_ROOT) roots.push(process.env.CONFORMANCE_PLAYWRIGHT_ROOT);
  return [...new Set(roots)];
}

export async function loadChromium() {
  const tried = [];
  for (const root of playwrightRoots()) {
    try {
      const require = createRequire(path.join(root, 'package.json'));
      const mod = await import(pathToFileURL(require.resolve('playwright')).href);
      // Imported by absolute path, playwright's CJS entry lands its real exports under
      // `default`; imported by bare name, node's interop hoists them. Take either.
      return mod.chromium || mod.default?.chromium;
    } catch {
      tried.push(root);
    }
  }
  throw new Error(
    'playwright is not resolvable from ' + tried.join(', ') + '. Run this from a repo that ' +
    'has it, or `npm i -D playwright@1.64.1` there first, then follow that repo\'s browser setup instructions.'
  );
}

export async function browserLaunchOptions() {
  for (const root of playwrightRoots()) {
    const helper = path.join(root, 'scripts', 'chrome-for-testing', 'browser-runtime.cjs');
    try {
      await lstat(helper);
    } catch (error) {
      if (error.code === 'ENOENT') continue;
      throw error;
    }
    const mod = await import(pathToFileURL(helper).href);
    const chromeOptions = mod.chromeOptions || mod.default?.chromeOptions;
    if (typeof chromeOptions !== 'function') throw new Error(`Pinned browser helper has no chromeOptions(): ${helper}`);
    return chromeOptions();
  }
  return {};
}

// Origin validation (spec §8), probed from OUTSIDE a browser.
//
// The in-page check cannot cover this and now says so. `Document-URL` is not a
// CORS-safelisted header, so the sandboxed frame's POST is preflighted, and a host
// that does not answer the preflight never sees the request at all. What the browser
// refused says nothing about what the host would have done, and scoring that a pass
// meant a host with no origin validation cleared the row.
//
// Node sends no preflight and honours no CORS, so the request the page could not make
// lands here exactly as written: the save route the page just used successfully, the
// foreign `Origin` a cross-site attacker sends, and the cookies their browser would
// attach. A host that writes this is missing the check §8 makes a MUST.
const FOREIGN_ORIGIN = 'https://mhf-conformance.invalid';

// A host injects ephemeral attributes on the root element at serve time (§4), and a
// token host mints a fresh token on every serve, so two reads of an unchanged document
// differ there and nowhere else. Comparing the body past the opening tag is what the
// page's own stripInjected does, in the one form available to a runner with no DOM.
const stripRootAttrs = (html) => (html === null ? null : html.replace(/<html\b[^>]*>/i, '<html>'));

async function originValidationRow({ target, token, cookies }) {
  const id = 'core.origin-probe';
  const name = 'A save carrying a foreign Origin cannot write to the document (server-side)';
  const headers = {};
  if (cookies.length) headers.Cookie = cookies.join('; ');
  const read = async () => {
    const res = await fetch(target, { headers, cache: 'no-store' });
    return res.ok ? stripRootAttrs(await res.text()) : null;
  };
  try {
    const before = await read();
    if (before === null) {
      return { id, name, blocking: true, status: 'na', reason: 'Could not read the document to compare against; nothing to check.' };
    }
    const route = token ? `/_/save/${encodeURIComponent(token)}` : '/_/save';
    const res = await fetch(new URL(route, target).href, {
      method: 'POST',
      headers: {
        ...headers,
        Origin: FOREIGN_ORIGIN,
        'Content-Type': 'text/html',
        'Document-URL': target,
      },
      body: '<!DOCTYPE html><html><body><p>written from ' + FOREIGN_ORIGIN + '</p></body></html>',
    });
    const after = await read();
    if (after !== before) {
      return {
        id,
        name,
        blocking: true,
        status: 'fail',
        reason: `A save carrying \`Origin: ${FOREIGN_ORIGIN}\` changed the stored document (status ${res.status}). ` +
          '§8 requires the host to validate the request\'s origin on every save; without it any page ' +
          'in the reader\'s browser can rewrite their documents.',
      };
    }
    return { id, name, blocking: true, status: 'pass', reason: `Refused (status ${res.status}); the document is unchanged.` };
  } catch (e) {
    // blocking, so an `na` here stops the gate rather than passing it. This probe is the
    // only place §8's origin MUST is checked from outside a browser; the in-page version
    // cannot check it, because the preflight is refused before the host ever sees it.
    return { id, name, blocking: true, status: 'na', reason: 'The probe did not complete: ' + (e.message || e) };
  }
}

// The file this runner puts in the host's served folder, if any. With `--page` the
// host places and names the page itself, so there is nothing here to write or delete.
export function servedPath({ root = '', page = '', place = true } = {}) {
  return root && place ? path.join(root, page) : null;
}

export async function runPageEngine(args) {
  const chromium = await loadChromium();

  const served = servedPath(args);
  if (served) await writeFile(served, await readFile(PAGE));

  // The caller has already said, explicitly, that this host's certificate is not
  // meant to verify. The browser gets that through ignoreHTTPSErrors below; node's
  // fetch, which the origin probe uses, has no per-request equivalent.
  if (args.insecure) process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

  const browser = await chromium.launch(await browserLaunchOptions());
  // --insecure is opt-in and never a default. A dev host commonly serves HTTPS with a
  // certificate no store trusts, and Chromium then refuses the page outright, which
  // surfaces as the run timing out waiting for results rather than as anything about
  // a certificate. Turning it on silently would be worse: this runner is pointed at
  // whatever URL a CI step names, and a gate that quietly accepts any certificate is
  // not a gate. So the caller says so.
  const context = await browser.newContext(args.insecure ? { ignoreHTTPSErrors: true } : {});

  // A cookie host authorizes a save by session, so the run needs one. Passed in
  // rather than obtained here: logging in is the host's own flow, it differs per
  // host, and a conformance runner has no business knowing anybody's credentials.
  if (args.cookies.length) {
    const origin = new URL(args.url);
    await context.addCookies(args.cookies.map((pair) => {
      const eq = pair.indexOf('=');
      if (eq < 1) throw new Error(`--cookie wants name=value, got ${JSON.stringify(pair)}`);
      return {
        name: pair.slice(0, eq),
        value: pair.slice(eq + 1),
        domain: origin.hostname,
        path: '/'
      };
    }));
  }

  const page = await context.newPage();

  // Surfaced, not swallowed: a page error is the difference between "the host failed a
  // check" and "the check never ran", and the row list alone cannot tell them apart.
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') pageErrors.push(m.text()); });

  let rows;
  try {
    const url = new URL(args.page, args.url.endsWith('/') ? args.url : args.url + '/').href;
    await page.goto(url, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => !!window.__hostTest, null, { timeout: 15000 });

    const defaults = await page.evaluate(() => window.__hostTest.defaults);
    // --token-from-page is the honest way to test a token host: the token is minted by
    // the host at serve time and binds to THIS file, so it cannot be known in advance
    // and must not be invented by the caller.
    const token = args.tokenFromPage ? defaults.token : (args.token || defaults.token);
    if (args.tokenFromPage && !token) {
      throw new Error('--token-from-page was given but the host served no save token attribute');
    }

    rows = await page.evaluate(
      ([target, token]) => window.__hostTest.run({ target, token }),
      [args.target || undefined, token]
    );

    // Run while the scratch document still exists, and before the browser closes, so
    // a host whose save route needs a live session still has one.
    rows.push(await originValidationRow({
      target: new URL(args.target || defaults.target, url).href,
      token,
      cookies: args.cookies,
    }));
  } finally {
    await browser.close();
    // Only what this runner put there. A page the HOST placed is the host's to clean
    // up, and deleting it would take the token binding with it.
    if (served && !args.keep) {
      await rm(served, { force: true });
      await rm(path.join(args.root, SCRATCH_NAME), { force: true });
    }
  }

  const checks = rows.map((row) => ({
    id: row.id,
    title: row.name,
    engine: 'page',
    status: row.status,
    detail: row.reason,
    blocking: Boolean(row.blocking),
  }));

  // A row that ended `na` could not answer: the fact is not observable from this page,
  // or the probe did not complete. Kept apart from the rest so the caller can tell it
  // from a host that skipped a capability it never announced.
  const unanswered = checks.filter((c) => c.status === 'na');

  return { checks, unanswered, pageErrors };
}
